module.exports = {
  jwtSecret: process.env.JWT_SECRET || '0bee035b-2fb9-48ad-a7f8-dea4c1adea28'
};