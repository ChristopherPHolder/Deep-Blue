const makeUnique = array => [...new Set(array)];

export default makeUnique;
